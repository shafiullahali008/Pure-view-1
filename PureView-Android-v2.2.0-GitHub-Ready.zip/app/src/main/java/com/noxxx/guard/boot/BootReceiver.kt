package com.noxxx.guard.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.noxxx.guard.NoXXXApp
import com.noxxx.guard.web.PrivateDns
import com.noxxx.guard.prayer.PrayerScheduler
import com.noxxx.guard.prayer.PrayerPreferences
import com.noxxx.guard.prayer.HourlyNotificationScheduler

/** Re-applies Private DNS after a reboot or update. The accessibility service restarts on its own. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_DATE_CHANGED, "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED")) return
        PrayerScheduler.schedule(context)
        HourlyNotificationScheduler.schedule(context, PrayerPreferences.read(context).hourlyNotificationsEnabled)
        val app = context.applicationContext as NoXXXApp
        app.store.tick()
        val s = app.store.state.value
        if (!s.settingsEditable && s.policy.requirePrivateDns) PrivateDns.enforce(context, s.policy.privateDnsHost)
    }
}
