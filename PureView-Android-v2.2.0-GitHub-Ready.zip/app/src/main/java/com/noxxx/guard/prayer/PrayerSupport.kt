package com.noxxx.guard.prayer

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.noxxx.guard.R
import com.noxxx.guard.ui.MainActivity
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

enum class JafariMethod(
    val key: String,
    val label: String,
    val fajrAngle: Double,
    val maghribAngle: Double,
    val ishaAngle: Double,
) {
    QUM("QUM", "Ja'fari · Qum", 16.0, 4.0, 14.0),
    TEHRAN("TEHRAN", "Ja'fari · Tehran", 17.7, 4.5, 14.0);

    companion object {
        fun fromKey(value: String?): JafariMethod = entries.firstOrNull { it.key == value } ?: QUM
    }
}

data class PrayerPreferences(
    val city: String = "Wah Cantt",
    val latitude: Double = 33.7995,
    val longitude: Double = 72.8205,
    val method: JafariMethod = JafariMethod.QUM,
    val remindersEnabled: Boolean = true,
    val azanEnabled: Boolean = true,
    val hourlyNotificationsEnabled: Boolean = true,
    val azanUri: String? = null,
) {
    companion object {
        private const val FILE = "pureview_prayer"

        fun uploadedAzanUri(context: Context): String =
            Uri.parse("android.resource://${context.packageName}/${R.raw.pureview_azan}").toString()

        fun read(context: Context): PrayerPreferences {
            val p = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            // Keep a user-selected document URI when present. OpenDocument grants a persistable
            // read permission; the bundled recording is the safe default and reset target.
            return PrayerPreferences(
                city = p.getString("city", "Wah Cantt") ?: "Wah Cantt",
                latitude = p.getString("lat", "33.7995")?.toDoubleOrNull() ?: 33.7995,
                longitude = p.getString("lon", "72.8205")?.toDoubleOrNull() ?: 72.8205,
                method = JafariMethod.fromKey(p.getString("method", JafariMethod.QUM.key)),
                remindersEnabled = p.getBoolean("reminders", true),
                azanEnabled = p.getBoolean("azan", true),
                hourlyNotificationsEnabled = p.getBoolean("hourly_notifications", true),
                azanUri = p.getString("azan_uri", uploadedAzanUri(context)) ?: uploadedAzanUri(context),
            )
        }

        fun write(context: Context, settings: PrayerPreferences) {
            context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
                .putString("city", settings.city)
                .putString("lat", settings.latitude.toString())
                .putString("lon", settings.longitude.toString())
                .putString("method", settings.method.key)
                .putBoolean("reminders", settings.remindersEnabled)
                .putBoolean("azan", settings.azanEnabled)
                .putBoolean("hourly_notifications", settings.hourlyNotificationsEnabled)
                .putString("azan_uri", settings.azanUri ?: uploadedAzanUri(context))
                .apply()
            PrayerScheduler.schedule(context)
            HourlyNotificationScheduler.schedule(context, settings.hourlyNotificationsEnabled)
        }
    }
}

data class PrayerTime(val name: String, val time: LocalTime)
data class DailyPrayerTimes(val date: LocalDate, val prayers: List<PrayerTime>) {
    fun next(now: LocalTime): PrayerTime? = prayers.firstOrNull { it.name != "Sunrise" && it.time.isAfter(now) }
}

/** Offline Ja'fari calculation. Default Qum profile; Tehran profile is selectable in the UI. */
object PrayerCalculator {
    private const val SUNRISE_ALTITUDE = -0.833

    fun calculate(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        zone: ZoneId = ZoneId.systemDefault(),
        method: JafariMethod = JafariMethod.QUM,
    ): DailyPrayerTimes {
        val n = date.dayOfYear
        val gamma = 2.0 * PI / 365.0 * (n - 1)
        val eqTime = 229.18 * (0.000075 + 0.001868 * cos(gamma) - 0.032077 * sin(gamma)
            - 0.014615 * cos(2 * gamma) - 0.040849 * sin(2 * gamma))
        val decl = 0.006918 - 0.399912 * cos(gamma) + 0.070257 * sin(gamma)
            - 0.006758 * cos(2 * gamma) + 0.000907 * sin(2 * gamma)
            - 0.002697 * cos(3 * gamma) + 0.00148 * sin(3 * gamma)
        val lat = Math.toRadians(latitude.coerceIn(-89.0, 89.0))
        val zoneOffset = date.atStartOfDay(zone).offset.totalSeconds / 60.0
        val solarNoon = 720.0 - 4.0 * longitude + zoneOffset - eqTime

        fun hourAngleMinutes(altitude: Double): Double {
            val h = Math.toRadians(altitude)
            val denominator = cos(lat) * cos(decl)
            if (kotlin.math.abs(denominator) < 1e-9) return 0.0
            val cosHour = (sin(h) - sin(lat) * sin(decl)) / denominator
            return Math.toDegrees(acos(cosHour.coerceIn(-1.0, 1.0))) * 4.0
        }
        fun toTime(minutes: Double): LocalTime {
            val m = ((minutes % 1440.0) + 1440.0) % 1440.0
            val h = floor(m).toInt()
            val seconds = ((m - h) * 60).toInt().coerceIn(0, 59)
            return LocalTime.of(h / 60, h % 60, seconds)
        }

        val fajr = toTime(solarNoon - hourAngleMinutes(-method.fajrAngle))
        val sunrise = toTime(solarNoon - hourAngleMinutes(SUNRISE_ALTITUDE))
        val dhuhr = toTime(solarNoon + 2.0)
        // Ja'fari/standard Asr uses a one-shadow-length factor (not the Hanafi two-shadow factor).
        val asrAltitude = Math.toDegrees(atan(1.0 / (1.0 + tan(kotlin.math.abs(lat - decl)))))
        val asr = toTime(solarNoon + hourAngleMinutes(asrAltitude))
        val maghrib = toTime(solarNoon + hourAngleMinutes(-method.maghribAngle))
        val isha = toTime(solarNoon + hourAngleMinutes(-method.ishaAngle))
        return DailyPrayerTimes(date, listOf(
            PrayerTime("Fajr", fajr), PrayerTime("Sunrise", sunrise), PrayerTime("Dhuhr", dhuhr),
            PrayerTime("Asr", asr), PrayerTime("Maghrib", maghrib), PrayerTime("Isha", isha),
        ))
    }
}

object PrayerScheduler {
    private const val ACTION_PRAYER = "com.noxxx.guard.action.PRAYER_ALARM"
    private fun requestCode(date: LocalDate, index: Int) = ((date.toEpochDay() % 100_000L) * 10L + index).toInt()

    fun hasExactAlarmAccess(context: Context): Boolean = Build.VERSION.SDK_INT < 31 ||
        context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun schedule(context: Context) {
        val settings = PrayerPreferences.read(context)
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val zone = ZoneId.systemDefault()
        for (offset in -3L..4L) {
            val date = LocalDate.now(zone).plusDays(offset)
            for (index in 0 until 6) {
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    action = ACTION_PRAYER
                    putExtra("date", date.toString())
                    putExtra("prayer_index", index)
                }
                PendingIntent.getBroadcast(context, requestCode(date, index), intent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let(alarmManager::cancel)
            }
        }
        if (!settings.remindersEnabled && !settings.azanEnabled) return
        val today = LocalDate.now(zone)
        for (offset in 0L..3L) {
            val date = today.plusDays(offset)
            val daily = PrayerCalculator.calculate(date, settings.latitude, settings.longitude, zone, settings.method)
            daily.prayers.forEachIndexed { index, prayer ->
                if (prayer.name == "Sunrise") return@forEachIndexed
                val fireAt = date.atTime(prayer.time).atZone(zone).toInstant().toEpochMilli()
                if (fireAt <= System.currentTimeMillis() + 2_000L) return@forEachIndexed
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    action = ACTION_PRAYER
                    putExtra("date", date.toString())
                    putExtra("prayer_index", index)
                    putExtra("prayer_name", prayer.name)
                    putExtra("prayer_time", prayer.time.format(DateTimeFormatter.ofPattern("hh:mm a", Locale.getDefault())))
                }
                val pending = PendingIntent.getBroadcast(context, requestCode(date, index), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                try {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (hasExactAlarmAccess(context)) alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pending)
                        else alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pending)
                    } else alarmManager.setExact(AlarmManager.RTC_WAKEUP, fireAt, pending)
                } catch (_: SecurityException) {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, fireAt, pending)
                }
            }
        }
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= 31) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply { data = Uri.parse("package:${context.packageName}") }
            runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }
}

/** Gentle opt-in hourly check-ins. Android may batch inexact repeating alarms to save battery. */
object HourlyNotificationScheduler {
    private const val ACTION_HOURLY = "com.noxxx.guard.action.HOURLY_CHECK_IN"
    private const val REQUEST_CODE = 8310
    private const val HOUR_MS = 60L * 60L * 1000L

    fun schedule(context: Context, enabled: Boolean) {
        val manager = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, HourlyNotificationReceiver::class.java).setAction(ACTION_HOURLY)
        val pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (!enabled) {
            manager.cancel(pending)
            pending.cancel()
            return
        }
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + HOUR_MS,
            HOUR_MS, pending)
    }
}

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.noxxx.guard.action.PRAYER_ALARM") return
        val settings = PrayerPreferences.read(context)
        val name = intent.getStringExtra("prayer_name") ?: return
        val time = intent.getStringExtra("prayer_time") ?: ""
        ensurePrayerChannels(context)
        if (settings.remindersEnabled) {
            val open = PendingIntent.getActivity(context, 8100, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(context, "pureview_prayer_reminders")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("$name prayer time")
                .setContentText("$name is due at $time in ${settings.city}.")
                .setStyle(NotificationCompat.BigTextStyle().bigText("It is time for $name prayer. ${settings.method.label} local time: $time."))
                .setContentIntent(open).setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH).build()
            context.getSystemService(NotificationManager::class.java).notify(name.hashCode(), notification)
        }
        if (settings.azanEnabled) {
            val play = Intent(context, PrayerAudioService::class.java).apply {
                data = Uri.parse(settings.azanUri ?: PrayerPreferences.uploadedAzanUri(context))
            }
            runCatching { ContextCompat.startForegroundService(context, play) }
        }
        PrayerScheduler.schedule(context)
    }
}

class HourlyNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.noxxx.guard.action.HOURLY_CHECK_IN") return
        val settings = PrayerPreferences.read(context)
        if (!settings.hourlyNotificationsEnabled) return
        ensurePrayerChannels(context)
        val messages = listOf(
            "Take a short pause, breathe, and reset your focus.",
            "A quick check-in: are you spending time on what matters today?",
            "Stand up, stretch gently, and give your eyes a screen break.",
            "One small positive choice can improve the next hour.",
            "Stay mindful. Your time and attention are valuable.",
            "Check your posture, relax your shoulders, and refocus.",
            "A little progress is still progress. Keep your next step simple.",
            "Pause notifications for a moment and focus on one task."
        )
        val prefs = context.getSharedPreferences("pureview_hourly", Context.MODE_PRIVATE)
        val index = prefs.getInt("next_message", 0).mod(messages.size)
        prefs.edit().putInt("next_message", (index + 1) % messages.size).apply()
        val open = PendingIntent.getActivity(context, 8311, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "pureview_hourly")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("PureView check-in")
            .setContentText(messages[index])
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(8312, notification)
    }
}

private fun ensurePrayerChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel("pureview_prayer_reminders") == null) {
            manager.createNotificationChannel(NotificationChannel("pureview_prayer_reminders", "Prayer reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Daily Ja'fari prayer time reminders from PureView"
            })
        }
        if (manager.getNotificationChannel("pureview_azan_playback") == null) {
            manager.createNotificationChannel(NotificationChannel("pureview_azan_playback", "Azan audio playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Ongoing notification while the uploaded Azan audio is playing"
                setSound(null, null)
            })
        }
        if (manager.getNotificationChannel("pureview_hourly") == null) {
            manager.createNotificationChannel(NotificationChannel("pureview_hourly", "Hourly PureView check-ins", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Optional hourly wellbeing and focus reminders"
            })
        }
    }
}

class PrayerAudioService : Service() {
    private var player: MediaPlayer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopPlayback()
            return START_NOT_STICKY
        }
        val audio = intent?.data ?: Uri.parse(PrayerPreferences.read(this).azanUri ?: PrayerPreferences.uploadedAzanUri(this))
        ensurePrayerChannels(this)
        val stopIntent = Intent(this, PrayerAudioService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 8200, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val ongoing = NotificationCompat.Builder(this, "pureview_azan_playback")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("PureView Azan")
            .setContentText("Your selected Azan audio is playing")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPending)
            .build()
        startForeground(NOTIFICATION_ID, ongoing)
        stopPlayback(releaseService = false)
        player = MediaPlayer().apply {
            try {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@PrayerAudioService, audio)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepareAsync()
            } catch (_: Exception) {
                runCatching { release() }
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun stopPlayback(releaseService: Boolean = true) {
        player?.let { runCatching { if (it.isPlaying) it.stop() }; runCatching { it.release() } }
        player = null
        if (releaseService) {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
            else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopPlayback(releaseService = false)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val ACTION_STOP = "com.noxxx.guard.action.STOP_AZAN"
        private const val NOTIFICATION_ID = 8201
    }
}
