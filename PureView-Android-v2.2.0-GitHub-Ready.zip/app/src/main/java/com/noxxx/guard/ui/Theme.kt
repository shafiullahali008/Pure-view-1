package com.noxxx.guard.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.noxxx.guard.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/*
 * PureView Aurora: an editorial pearl surface with electric indigo, glacier cyan and orchid accents.
 * Dark mode uses an ink-navy base with luminous cyan and violet. Motion is intentionally restrained
 * so animations remain legible and battery-friendly. Headings use bundled Cormorant Garamond (OFL).
 */

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun cormorant(weight: Int, italic: Boolean = false) = Font(
    if (italic) R.font.cormorant_italic else R.font.cormorant,
    FontWeight(weight),
    if (italic) FontStyle.Italic else FontStyle.Normal,
    variationSettings = FontVariation.Settings(FontVariation.weight(weight)),
)

/** Serif for headings, scripture and the streak number. */
val Serif = FontFamily(
    cormorant(500), cormorant(600), cormorant(700),
    cormorant(500, italic = true), cormorant(600, italic = true),
)

private val TempleLight = lightColorScheme(
    primary = Color(0xFF4E55C7), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE4E5FF), onPrimaryContainer = Color(0xFF171C64),
    secondary = Color(0xFF087F91), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD5F5F7), onSecondaryContainer = Color(0xFF073B43),
    tertiary = Color(0xFF9656B9), onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF3DFFF), onTertiaryContainer = Color(0xFF3D1457),
    error = Color(0xFFB3264B), onError = Color(0xFFFFFFFF), errorContainer = Color(0xFFFFDCE5), onErrorContainer = Color(0xFF5B1028),
    background = Color(0xFFF5F6FC), onBackground = Color(0xFF181B2A),
    surface = Color(0xFFFCFCFF), onSurface = Color(0xFF181B2A),
    surfaceVariant = Color(0xFFE9EAF4), onSurfaceVariant = Color(0xFF565B72),
    outline = Color(0xFF9297B0), outlineVariant = Color(0xFFDADCEC),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF9F9FF),
    surfaceContainer = Color(0xFFF0F1FA), surfaceContainerHigh = Color(0xFFE9EAF6), surfaceContainerHighest = Color(0xFFE1E3F1),
)

private val TempleDark = darkColorScheme(
    primary = Color(0xFFB7B9FF), onPrimary = Color(0xFF20236E),
    primaryContainer = Color(0xFF383C93), onPrimaryContainer = Color(0xFFE2E2FF),
    secondary = Color(0xFF77DCE8), onSecondary = Color(0xFF003940),
    secondaryContainer = Color(0xFF07545F), onSecondaryContainer = Color(0xFFC9F7FB),
    tertiary = Color(0xFFE0A6FF), onTertiary = Color(0xFF4D1767),
    tertiaryContainer = Color(0xFF673481), onTertiaryContainer = Color(0xFFF5D9FF),
    error = Color(0xFFFFB3C5), onError = Color(0xFF650D2C), errorContainer = Color(0xFF8E2948), onErrorContainer = Color(0xFFFFDCE5),
    background = Color(0xFF0C1020), onBackground = Color(0xFFE9E9F7),
    surface = Color(0xFF13182A), onSurface = Color(0xFFE9E9F7),
    surfaceVariant = Color(0xFF252B43), onSurfaceVariant = Color(0xFFBFC2DA),
    outline = Color(0xFF737A9A), outlineVariant = Color(0xFF303650),
    surfaceContainerLowest = Color(0xFF080B16), surfaceContainerLow = Color(0xFF171C30),
    surfaceContainer = Color(0xFF1B2137), surfaceContainerHigh = Color(0xFF232A43), surfaceContainerHighest = Color(0xFF2C3350),
)

private val NoXXXShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

private fun typography(): Typography {
    val t = Typography()
    // "lnum": full-height numbers. Cormorant defaults to old-style figures, where 0 looks like a small o.
    fun serif(s: androidx.compose.ui.text.TextStyle, w: Int = 600) = s.copy(fontFamily = Serif, fontWeight = FontWeight(w), fontFeatureSettings = "lnum")
    return t.copy(
        displayLarge = serif(t.displayLarge), displayMedium = serif(t.displayMedium), displaySmall = serif(t.displaySmall),
        headlineLarge = serif(t.headlineLarge), headlineMedium = serif(t.headlineMedium), headlineSmall = serif(t.headlineSmall),
        titleLarge = serif(t.titleLarge, 600).copy(fontSize = t.titleLarge.fontSize * 1.15f),
    )
}

enum class ThemeMode(val label: String, val description: String) {
    SYSTEM("Match phone", "Light or dark, following your phone's setting"),
    LIGHT("Light", "Pearl, electric indigo and glacier cyan"),
    DARK("Dark", "Ink navy, luminous cyan and orchid"),
}

/** The chosen theme, remembered on this phone. Not part of the locked settings. */
object Appearance {
    private const val PREFS = "appearance"
    private val _mode = MutableStateFlow(ThemeMode.SYSTEM)
    val mode: StateFlow<ThemeMode> = _mode.asStateFlow()

    fun load(context: Context) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("mode", null)
        _mode.value = ThemeMode.entries.firstOrNull { it.name == saved } ?: ThemeMode.SYSTEM
    }

    fun set(context: Context, mode: ThemeMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("mode", mode.name).apply()
        _mode.value = mode
    }
}

@Composable
fun NoXXXTheme(content: @Composable () -> Unit) {
    val system = isSystemInDarkTheme()
    val dark = when (Appearance.mode.collectAsState().value) {
        ThemeMode.SYSTEM -> system
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(colorScheme = if (dark) TempleDark else TempleLight, typography = typography(), shapes = NoXXXShapes, content = content)
}
