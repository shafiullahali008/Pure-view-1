package com.noxxx.guard.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private enum class MiniGame(val title: String, val subtitle: String) {
    MEMORY("Memory Matrix", "Match all pairs"),
    FOCUS("Focus Sprint", "15-second focus challenge"),
    SESSION("Focus Session", "25/50-minute Pomodoro timer"),
    MATH("Quick Math", "Solve short number challenges"),
}

fun androidx.compose.foundation.lazy.LazyListScope.gamesScreen() {
    item { GamesDashboard() }
}

@Composable
private fun GamesDashboard() {
    var selected by remember { mutableStateOf<MiniGame?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        GamesHero()
        AnimatedContent(targetState = selected, label = "game-selector") { game ->
            if (game == null) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("FREE MINI GAMES", style = MaterialTheme.typography.labelLarge, letterSpacing = 1.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    MiniGame.entries.forEach { option ->
                        GameChoiceCard(option) { selected = option }
                    }
                    Text("All games run offline. No accounts, ads, subscriptions or paid unlocks.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = { selected = null }) { Text("← All games") }
                    when (game) {
                        MiniGame.MEMORY -> MemoryGame()
                        MiniGame.FOCUS -> FocusGame()
                        MiniGame.SESSION -> FocusSessionGame()
                        MiniGame.MATH -> QuickMathGame()
                    }
                }
            }
        }
    }
}

@Composable
private fun GamesHero() {
    val transition = rememberInfiniteTransition(label = "games-hero")
    val tilt by transition.animateFloat(-3f, 3f, infiniteRepeatable(tween(2_700), RepeatMode.Reverse), label = "tilt")
    Box(
        Modifier.fillMaxWidth().shadow(14.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF15183B), Color(0xFF3540A0), Color(0xFF087F91))))
            .padding(22.dp)
    ) {
        Box(Modifier.align(Alignment.TopEnd).size(112.dp).graphicsLayer(rotationZ = tilt, rotationX = 12f)) {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF77DCE8).copy(alpha = .86f), Color(0xFFE0A6FF).copy(alpha = .24f), Color.Transparent))))
            Box(Modifier.padding(19.dp).size(74.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF77DCE8), Color(0xFFB7B9FF)))).border(1.dp, Color.White.copy(alpha = .65f), CircleShape))
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("PUREVIEW · PLAY", color = Color(0xFF9DECF2), style = MaterialTheme.typography.labelLarge, letterSpacing = 2.sp)
            Text("Take a mindful break", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Quick offline games for focus and memory.", color = Color.White.copy(alpha = .76f), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun GameChoiceCard(game: MiniGame, onClick: () -> Unit) {
    val icon = when (game) {
        MiniGame.MEMORY -> Icons.Filled.Extension
        MiniGame.FOCUS, MiniGame.SESSION -> Icons.Filled.Timer
        MiniGame.MATH -> Icons.Filled.Calculate
    }
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(22.dp)),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Color(0xFFD5F5F7), Color(0xFFE4E5FF)))), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Color(0xFF353CA0), modifier = Modifier.size(26.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(game.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(game.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Play  ›", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GamePanel(title: String, instruction: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(instruction, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
private fun MemoryGame() {
    val symbolSet = listOf("◆", "●", "▲", "✦", "✿", "⬟", "☾", "✚")
    var cards by remember { mutableStateOf(symbolSet.flatMap { listOf(it, it) }.shuffled()) }
    val opened = remember { mutableStateListOf<Int>() }
    val matched = remember { mutableStateListOf<Int>() }
    var moves by remember { mutableIntStateOf(0) }
    var mismatch by remember { mutableStateOf(false) }

    LaunchedEffect(opened.toList()) {
        if (opened.size == 2) {
            moves++
            val first = opened[0]
            val second = opened[1]
            if (cards[first] == cards[second]) {
                matched.add(first); matched.add(second)
                opened.clear()
            } else {
                mismatch = true
                delay(700)
                opened.clear()
                mismatch = false
            }
        }
    }

    GamePanel("Memory Matrix", "Flip two tiles at a time and find all eight matching pairs.") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Moves: $moves", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("Pairs: ${matched.size / 2}/8", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { matched.clear(); opened.clear(); moves = 0; cards = symbolSet.flatMap { listOf(it, it) }.shuffled() }) { Text("Restart") }
        }
        for (row in 0 until 4) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (col in 0 until 4) {
                    val index = row * 4 + col
                    val visible = index in opened || index in matched
                    Surface(
                        modifier = Modifier.weight(1f).aspectRatio(1f).clickable(enabled = !visible && opened.size < 2) { opened.add(index) },
                        shape = RoundedCornerShape(14.dp),
                        color = if (visible) Color(0xFFE3F6EF) else Color(0xFF273B63),
                        shadowElevation = if (visible) 1.dp else 5.dp,
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(if (visible) cards[index] else "•", color = if (visible) Color(0xFF234E46) else Color(0xFFD2D9F5), fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (matched.size == 16) Text("Complete. You matched every pair in $moves moves.", color = Color(0xFF23865B), fontWeight = FontWeight.Bold)
        else if (mismatch) Text("Not a match — try again.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FocusGame() {
    var running by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(15) }
    var taps by remember { mutableIntStateOf(0) }
    LaunchedEffect(running) {
        if (running) {
            while (seconds > 0) { delay(1_000); seconds-- }
            running = false
        }
    }
    GamePanel("Focus Sprint", "Tap the target as many times as you can in 15 seconds.") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Time: ${seconds}s", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("Taps: $taps", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Surface(
                onClick = { if (running) taps++ },
                enabled = running,
                modifier = Modifier.size(154.dp).shadow(12.dp, CircleShape),
                shape = CircleShape,
                color = Color(0xFF273F69),
                shadowElevation = 8.dp,
            ) {
                Box(contentAlignment = Alignment.Center) { Text(if (running) "TAP" else "READY", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
            }
        }
        if (!running && seconds == 0) Text("Session complete: $taps taps.", color = Color(0xFF23865B), fontWeight = FontWeight.Bold)
        Button(enabled = !running, onClick = { taps = 0; seconds = 15; running = true }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "Timer running" else if (seconds == 0) "Play again" else "Start 15-second round") }
    }
}

@Composable
private fun FocusSessionGame() {
    var durationMinutes by remember { mutableIntStateOf(25) }
    var remainingSeconds by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }

    LaunchedEffect(running) {
        while (running && remainingSeconds > 0) {
            delay(1_000)
            remainingSeconds = (remainingSeconds - 1).coerceAtLeast(0)
        }
        if (remainingSeconds == 0) running = false
    }

    val totalSeconds = durationMinutes * 60
    val progress = 1f - (remainingSeconds / totalSeconds.toFloat()).coerceIn(0f, 1f)
    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val pulse = rememberInfiniteTransition(label = "focus-session-pulse")
    val breathe by pulse.animateFloat(0.97f, 1.035f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "focus-breathe")

    GamePanel("Focus Session", "Choose a calm work block. The timer does not block apps or lock your phone.") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(25, 50).forEach { preset ->
                androidx.compose.material3.FilterChip(
                    selected = durationMinutes == preset,
                    enabled = !running,
                    onClick = { durationMinutes = preset; remainingSeconds = preset * 60 },
                    label = { Text("$preset minutes") },
                )
            }
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(190.dp).graphicsLayer { scaleX = if (running) breathe else 1f; scaleY = if (running) breathe else 1f }
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF4E55C7), Color(0xFF087F91), Color(0xFF14203D))))
                    .border(3.dp, Color(0xFF9BEAF1).copy(alpha = .75f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("%02d:%02d".format(minutes, seconds), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text(if (running) "FOCUSING" else if (remainingSeconds == 0) "COMPLETE" else "READY", color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.labelMedium, letterSpacing = 1.8.sp)
                }
            }
        }
        androidx.compose.material3.LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
            color = MaterialTheme.colorScheme.secondary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { running = !running },
                enabled = remainingSeconds > 0,
                modifier = Modifier.weight(1f),
            ) { Text(if (running) "Pause" else if (remainingSeconds == 0) "Completed" else if (remainingSeconds == totalSeconds) "Start focus" else "Resume") }
            OutlinedButton(
                onClick = { running = false; remainingSeconds = totalSeconds },
                modifier = Modifier.weight(1f),
            ) { Text("Reset") }
        }
        Text(
            if (remainingSeconds == 0) "Good work. Take a short screen break before your next task."
            else "Tip: choose one task, silence non-essential alerts, and take a short break when the timer ends.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

private data class MathQuestion(val prompt: String, val answer: Int, val options: List<Int>)
private fun nextMathQuestion(): MathQuestion {
    val a = Random.nextInt(3, 20)
    val b = Random.nextInt(2, 15)
    val answer = a + b
    val options = (listOf(answer) + listOf(answer - Random.nextInt(1, 6), answer + Random.nextInt(1, 6), answer + Random.nextInt(7, 12))).distinct().shuffled()
    return MathQuestion("$a + $b = ?", answer, options)
}

@Composable
private fun QuickMathGame() {
    var question by remember { mutableStateOf(nextMathQuestion()) }
    var score by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf("Choose the correct answer.") }
    GamePanel("Quick Math", "Solve each addition challenge. Your score stays on this screen only.") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Score: $score", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("Questions: $total", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFF292E89), Color(0xFF087F91)))).padding(22.dp), contentAlignment = Alignment.Center) {
            Text(question.prompt, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
        question.options.forEach { option ->
            OutlinedButton(onClick = {
                total++
                if (option == question.answer) { score++; feedback = "Correct — nice work." }
                else feedback = "The correct answer was ${question.answer}. Keep going."
                question = nextMathQuestion()
            }, modifier = Modifier.fillMaxWidth()) { Text(option.toString()) }
        }
        Text(feedback, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { score = 0; total = 0; feedback = "New round started."; question = nextMathQuestion() }) { Text("Reset score") }
    }
}
