# Build the PureView APK with GitHub Actions

This package contains the Android source project and the workflow file `.github/workflows/pureview-github-apk.yml`.

## Mobile-friendly setup

1. Upload `PureView-Android-v2.2.0-GitHub-Ready.zip` to the root of your GitHub repository.
2. In the repository, choose **Add file → Create new file** and enter this exact filename: `.github/workflows/pureview-github-apk.yml`.
3. Copy the contents of the separately supplied `pureview-github-apk.yml` file into the editor, then commit it to `main` or `master`.
4. Open **Actions → PureView Android APK**. A push starts the build automatically; you can also use **Run workflow**.
5. Open the completed run and download the **PureView-Android-APK** artifact. GitHub downloads it as a ZIP; extract it to get `app-debug.apk`.

The workflow can build either the source ZIP uploaded to the repository root or an already-extracted Android project. It uses JDK 17, Android SDK Platform 35, the project's Gradle Wrapper, and GitHub Actions artifact storage.

## Notes

- This produces a **debug APK for testing**, not a Play Store release build.
- Keep `LICENSE` and the files in `licenses/`; they are not build blockers and preserve the source project's licensing notices.
- Never upload signing keys, keystore files, passwords, or API secrets to the repository.
- The GitHub artifact can only be downloaded by an account with access to the repository and workflow run.
